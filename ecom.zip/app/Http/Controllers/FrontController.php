<?php

namespace App\Http\Controllers;

use App\Models\Front;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Cookie;

use Crypt;
use Mail;

class FrontController extends Controller
{
   
    public function index(Request $request)
    {

        $result['home_categories']=DB::table('categories')
            ->where(['status'=>1])
            ->get();


        
            foreach($result['home_categories'] as $list ){
                $result['home_categories_product'][$list->id]=
                     DB::table('products')
                     ->where(['status'=>1])
                     ->where(['category_id'=>$list->id])
                     ->get();
            }
            $result['home_featured_product'][$list->id]=
                DB::table('products')
                ->where(['status'=>1])
                ->get();

            return view('front.index',$result);
        }

        public function category(Request $request,$id)
    {
        $sort="";
        if($request->get('sort')!=null)
        {
            $sort=$request->get('sort');
        }


        
        $query= DB::table('products');
        $query= $query->leftJoin('categories','categories.id','=','products.category_id');
        $query=$query->where(['products.status'=>1]);
            //->where(['categories.id'=>$id])
        

        if($sort=='name'){
            $query=$query->orderby('products.name','asc');
        }
        if($sort=='date'){
            $query=$query->orderby('products.id','desc');
        }
        $query=$query->get();
        $result['product']=$query;
            
        return view('front.category',$result);
    }

        public function product(Request $request,$id)
        {
            $result['product']=
            DB::table('products')
            ->where(['status'=>1])
            ->where(['id'=>$id])
            ->get();

            $result['related_product']=
            DB::table('products')
            ->where(['status'=>1])
            ->where('id','!=',$id)
            ->where(['category_id'=>$result['product'][0]->category_id])
            ->get();

            return view('front.product',$result);
        }
        public function add_to_cart(Request $request)
    {
        if($request->session()->has('FRONT_USER_LOGIN')){
            $uid=$request->session()->get('FRONT_USER_ID');
            $user_type="Reg";
        }else{
            $uid=getUserTempId();
            $user_type="Not-Reg";
        }
        $pqty=$request->post('pqty');
        $product_id=$request->post('product_id');

        $result=DB::table('products')
        ->select('products.id')
            ->where(['products.id'=>$product_id])
            ->get();
           $product_id=$result[0]->id;


           $check=DB::table('cart')
            ->where(['user_id'=>$uid])
            ->where(['user_type'=>$user_type])
            ->where(['product_id'=>$product_id])
            ->get();
        if(isset($check[0])){
            $update_id=$check[0]->id;
            if($pqty==0){
                DB::table('cart')
                    ->where(['id'=>$update_id])
                    ->delete();
                $msg="removed";
            }else{
                DB::table('cart')
                    ->where(['id'=>$update_id])
                    ->update(['qty'=>$pqty]);
                $msg="updated";
            }
            
        }else{
            $id=DB::table('cart')->insertGetId([
                'user_id'=>$uid,
                'user_type'=>$user_type,
                'product_id'=>$product_id,
                'qty'=>$pqty,
                'added_on'=>date('Y-m-d h:i:s')
            ]);
            $msg="added";
        }

        $result=DB::table('cart')
        ->leftjoin('products','products.id','=','cart.product_id')
       // ->where(['user_id'=>$uid])
        ->where(['user_type'=>$user_type])
        ->select('cart.qty','products.name','products.image','products.price','products.id as pid')
        ->get();

        return response()->json(['msg'=>$msg,'data'=>$result,'totalItem'=>count($result)]);
    }
   public function cart(Request $request)
   {
    if($request->session()->has('FRONT_USER_LOGIN')){
        $uid=$request->session()->get('FRONT_USER_ID');
        $user_type="Reg";
    }else{
        $uid=getUserTempId();
        $user_type="Not-Reg";
    }

    $result['list']=DB::table('cart')
    ->leftjoin('products','products.id','=','cart.product_id')
   // ->where(['user_id'=>$uid])
    ->where(['user_type'=>$user_type])
    ->select('cart.qty','products.name','products.image','products.price','products.id as pid')
    ->get();
    return view('front.cart',$result);
   }
   public function search(Request $request,$str)
   {
    $result['product']=
    $query=DB::table('products');
    $query=$query->leftJoin('categories','categories.id','=','products.category_id');
    $query=$query->where(['products.status'=>1]);
    $query=$query->where('name','like',"%$str%");
    $query=$query->orwhere('short_desc','like',"%$str%");
    $query=$query->orwhere('desc','like',"%$str%");
    $query=$query->orwhere('keywords','like',"%$str%");
    $query=$query->distinct()->select('products.*');
    $query=$query->get();
    $result['product']=$query;
       

       return view('front.search',$result);
      
   }
   public function registration(Request $request)
   {
       $result=[];
       return view('front.registration',$result);
   }
   
   public function registration_process(Request $request)
   {
      $valid=Validator::make($request->all(),[
           "name"=>'required',
           "email"=>'required|email|unique:customers,email',
           "password"=>'required',
           "mobile"=>'required|numeric|digits:10',
      ]);

      if(!$valid->passes()){
        return response()->json(['status'=>'error','error'=>$valid->errors()->toArray()]);
   }else{
        $rand_id=rand(111111111,999999999);
        $arr=[
            "name"=>$request->name,
            "email"=>$request->email,
            "password"=>Crypt::encrypt($request->password),
            "mobile"=>$request->mobile,
            "status"=>1,
            "is_verify"=>0,
            "rand_id"=>$rand_id,
            "created_at"=>date('Y-m-d h:i:s'),
            "updated_at"=>date('Y-m-d h:i:s')
        ];
        $query=DB::table('customers')->insert($arr);
        if($query){

            $data=['name'=>$request->name,'rand_id'=>$rand_id];
            $user['to']=$request->email;
            Mail::send('front/email_verification',$data,function($messages) use ($user){
                $messages->to($user['to']);
                $messages->subject('Email Id Verification');
            });

            return response()->json(['status'=>'success','msg'=>"Registration successfully. Please check your email id for verification"]);
        }

   }
}
   public function login_process(Request $request)
   {

       $result=DB::table('customers')  
           ->where(['email'=>$request->str_login_email])
           ->get(); 
       
       if(isset($result[0])){
           $db_pwd=Crypt::decrypt($result[0]->password);
           if($db_pwd==$request->str_login_password){

            if($request->rememberme===null){
                setcookie('login_email',$request->str_login_email,100);
                setcookie('login_pwd',$request->str_login_password,100);
            }else{
               setcookie('login_email',$request->str_login_email,time()+60*60*24*100);
               setcookie('login_pwd',$request->str_login_password,time()+60*60*24*100);
            }


               $request->session()->put('FRONT_USER_LOGIN',true);
               $request->session()->put('FRONT_USER_ID',$result[0]->id);
               $request->session()->put('FRONT_USER_NAME',$result[0]->name);
               $status="success";
               $msg="";
          
               $getUserTempId=getUserTempId();
               DB::table('cart')  
                   ->where(['user_id'=>$getUserTempId,'user_type'=>'Not-Reg'])
                   ->update(['user_id'=>$result[0]->id,'user_type'=>'Reg']);
               
           }else{
               $status="error";
               $msg="Please enter valid password";
           }
       }else{
           $status="error";
           $msg="Please enter valid email id";
       }
      return response()->json(['status'=>$status,'msg'=>$msg]); 
      //$request->password
   }
   
   public function email_verification(Request $request,$id)
    {
        $result=DB::table('customers')  
            ->where(['rand_id'=>$id])
            ->get(); 

        if(isset($result[0])){
            DB::table('customers')  
            ->where(['id'=>$result[0]->id])
            ->update(['is_verify'=>1,'rand_id'=>'']);
        return view('front.verification');
        }else{
            return redirect('/');
        }
    }

    

    public function forgot_password(Request $request)
    {
        
        $result=DB::table('customers')  
            ->where(['email'=>$request->str_forgot_email])
            ->get(); 
        $rand_id=rand(111111111,999999999);
        if(isset($result[0])){

            DB::table('customers')  
                ->where(['email'=>$request->str_forgot_email])
                ->update(['is_forgot_password'=>1,'rand_id'=>$rand_id]);

            $data=['name'=>$result[0]->name,'rand_id'=>$rand_id];
            $user['to']=$request->str_forgot_email;
            Mail::send('front/forgot_email',$data,function($messages) use ($user){
                $messages->to($user['to']);
                $messages->subject("Forgot Password");
            });
            return response()->json(['status'=>'success','msg'=>'Please check your email for password']); 
        }else{
            return response()->json(['status'=>'error','msg'=>'Email id not registered']); 
        }
    }


    public function forgot_password_change(Request $request,$id)
    {
        $result=DB::table('customers')  
            ->where(['rand_id'=>$id])
            ->where(['is_forgot_password'=>1])
            ->get(); 

        if(isset($result[0])){
            $request->session()->put('FORGOT_PASSWORD_USER_ID',$result[0]->id);
        
            return view('front.forgot_password_change');
        }else{
            return redirect('/');
        }
    }

    public function forgot_password_change_process(Request $request)
    {
        DB::table('customers')  
            ->where(['id'=>$request->session()->get('FORGOT_PASSWORD_USER_ID')])
            ->update(
                [
                    'is_forgot_password'=>0,
                    'password'=>Crypt::encrypt($request->password)   ,
                    'rand_id'=>''
                ]
            ); 
        return response()->json(['status'=>'success','msg'=>'Password changed']);     
    }
    public function checkout(Request $request)
    {
        $result['cart_data']=getAddToCartTotalItem();

        if(isset($result['cart_data'][0])){

            if($request->session()->has('FRONT_USER_LOGIN')){
                $uid=$request->session()->get('FRONT_USER_ID');
                $customer_info=DB::table('customers')  
                    ->where(['id'=> $uid])
                     ->get(); 
                $result['customers']['name']=$customer_info[0]->name;
                $result['customers']['email']=$customer_info[0]->email;
                $result['customers']['mobile']=$customer_info[0]->mobile;
                $result['customers']['address']=$customer_info[0]->address;
                $result['customers']['city']=$customer_info[0]->city;
            }else{
                $result['customers']['name']='';
                $result['customers']['email']='';
                $result['customers']['mobile']='';
                $result['customers']['address']='';
                $result['customers']['city']='';
            }

            return view('front.checkout',$result);
        }else{
            return redirect('/');
        }
    }
    public function apply_coupon_code(Request $request)
    {
         $arr=apply_coupon_code($request->coupon_code);
         $arr=json_decode($arr,true);

         return response()->json(['status'=>$arr['status'],'msg'=>$arr['msg'],'totalPrice'=>$arr['totalPrice']]);
    }
    
    public function remove_coupon_code(Request $request)
    {
        $totalPrice=0;
        $result=DB::table('coupons')  
        ->where(['code'=>$request->coupon_code])
        ->get(); 
        $getAddToCartTotalItem=getAddToCartTotalItem();
        $totalPrice=0;
        foreach($getAddToCartTotalItem as $list){
            $totalPrice=$totalPrice+($list->qty*$list->price);
        }  
        
        return response()->json(['status'=>'success','msg'=>'Coupon code removed','totalPrice'=>$totalPrice]); 
    }

    public function place_order(Request $request)
    {
        $payment_url='';
        if($request->session()->has('FRONT_USER_LOGIN')){
            $coupon_value=0;
            if($request->coupon_code!=''){
                $arr=apply_coupon_code($request->coupon_code);
                $arr=json_decode($arr,true);
                if($arr['status']=='success'){
                    $coupon_value=$arr['coupon_code_value'];
                }else{
                    return response()->json(['status'=>'false','msg'=>$arr['msg']]);
                }
            }
            

            $uid=$request->session()->get('FRONT_USER_ID');
            $totalPrice=0;
            $getAddToCartTotalItem=getAddToCartTotalItem();
            foreach($getAddToCartTotalItem as $list){
                $totalPrice=$totalPrice+($list->qty*$list->price);
            }  
            $arr=[
                "customers_id"=>$uid,
                "name"=>$request->name,
                "email"=>$request->email,
                "mobile"=>$request->mobile,
                "address"=>$request->address,
                "city"=>$request->city,
                "coupon_code"=>$request->coupon_code,
                "coupon_value"=>$coupon_value,
                "payment_type"=>$request->payment_type,
                "payment_status"=>"Pending",
                "total_amt"=>$totalPrice,
                "order_status"=>1,
                "added_on"=>date('Y-m-d h:i:s')
            ];
            $order_id=DB::table('orders')->insertGetId($arr);

            if($order_id>0){
                foreach($getAddToCartTotalItem as $list){
                    $prductDetailArr['product_id']=$list->pid;
                    $prductDetailArr['price']=$list->price;
                    $prductDetailArr['qty']=$list->qty;
                    $prductDetailArr['orders_id']=$order_id;
                    DB::table('orders_details')->insert($prductDetailArr);
                }  
                
                if($request->payment_type=='Gateway'){
                    $final_amt=$totalPrice-$coupon_value;
                    $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, 'https://api.instamojo.com/v2/payment_requests/');
            curl_setopt($ch, CURLOPT_HEADER, FALSE);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
            curl_setopt($ch, CURLOPT_HTTPHEADER,array('Authorization:e2c3fe6f0222cda0f5d4499cb383bfb4'));
                    $payload = Array(
                        'purpose' => 'Buy Product',
                        'amount' => $final_amt,
                        'phone' => $request->mobile,
                        'buyer_name' =>$request->name,
                        'redirect_url' => 'http://127.0.0.1:8000/instamojo_payment_redirect',
                        'send_email' => true,
                        'send_sms' => true,
                        'email' => $request->email,
                        'allow_repeated_payments' => false
                    );
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
                    $response = curl_exec($ch);
                    curl_close($ch); 
                    $response=json_decode($response);
                    if(isset($response->payment_request->id)){
                        $txn_id=$response->payment_request->id;
                        DB::table('orders')
                        ->where(['id'=>$order_id])
                        ->update(['txn_id'=>$txn_id]);
                        $payment_url=$response->payment_request->longurl;
                    }else{
                        $msg="";
                        foreach($response->message as $key=>$val){
                            $msg.=strtoupper($key).": ".$val[0].'<br/>';
                        }
                        return response()->json(['status'=>'error','msg'=>$msg,'payment_url'=>'']); 
                    }
                    
                }
                DB::table('cart')->where(['user_id'=>$uid,'user_type'=>'Reg'])->delete();
                $request->session()->put('ORDER_ID',$order_id);

                $status="success";
                $msg="Order placed";
            }else{
                $status="false";
                $msg="Please try after sometime";
            }
        }else{
            $status="false";
            $msg="Please login to place order";
        }
        return response()->json(['status'=>$status,'msg'=>$msg,'payment_url'=>$payment_url]); 
    }

    public function order_placed(Request $request)
    {
        if($request->session()->has('ORDER_ID')){
            return view('front.order_placed');
        }else{
            return redirect('/');
        }
    }
    public function instamojo_payment_redirect(Request $request)
    {
        prx($_GET);
    }
    
}