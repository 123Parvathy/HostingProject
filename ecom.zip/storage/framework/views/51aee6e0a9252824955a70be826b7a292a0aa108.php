
<?php $__env->startSection('page_title','Manage Coupon Page'); ?>
<?php $__env->startSection('coupon_select','active'); ?>
<?php $__env->startSection('container'); ?>
    <h1 class="mb10">Manage Coupon</h1>
    <a href="<?php echo e(url('admin/coupon')); ?>">
        <button type="button" class="btn btn-success">
            Back
        </button>
    </a>
    <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('coupon.manage_coupon_process')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="title" class="control-label mb-1">Title</label>
                                        <input id="title" value="<?php echo e($title); ?>" name="title" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="code" class="control-label mb-1">Code</label>
                                        <input id="code" value="<?php echo e($code); ?>" name="code" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?php echo e($message); ?>	
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="value" class="control-label mb-1">Value</label>
                                        <input id="value" value="<?php echo e($value); ?>" name="value" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="value" class="control-label mb-1">Type</label>
                                        <select id="type" name="type" class="form-control" required>
                    <?php if($type=='Value'): ?>
                    <option value="Value" selected>Value</option>
                    <option value="Per">Per</option>
                    <?php elseif($type=='Per'): ?>
                    <option value="Value">Value</option>
                    <option value="Per" selected>Per</option>
                    <?php else: ?>
                    <option value="Value">Value</option>
                    <option value="Per">Per</option>
                    <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="title" class="control-label mb-1">Min Order Amt</label>
                                        <input id="min_order_amt" value="<?php echo e($min_order_amt); ?>" name="min_order_amt" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="code" class="control-label mb-1">IS One Time</label>
                                        <select id="is_one_time" name="is_one_time" class="form-control" required>
                    <?php if($is_one_time=='1'): ?>
                    <option value="1" selected>Yes</option>
                    <option value="0">No</option>
                    <?php else: ?>
                    <option value="1">Yes</option>
                    <option value="0" selected>No</option>
                    <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                    Submit
                                </button>
                            </div>
                            <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                        </form>
                    </div>
                </div>
             </div>
        </div>
        </div>
    </div>
                        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\ecom\my_ecom\resources\views/admin/manage_coupon.blade.php ENDPATH**/ ?>