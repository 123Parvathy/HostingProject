Welcome {{$name}}<br/>
<a href="{{url('/verification/')}}/{{$rand_id}}">Click here</a> to verify your email id.